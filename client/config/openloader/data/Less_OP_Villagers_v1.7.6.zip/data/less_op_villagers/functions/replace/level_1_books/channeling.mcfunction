# level_1_books/channeling

loot spawn ~ ~ ~ loot less_op_villagers:cost/book_3_high
tag @e[type=item,nbt={Item:{tag:{LOVcost:1b}}},limit=1] add LOVcost
data remove entity @e[type=item,tag=LOVcost,limit=1] Item.tag.LOVcost

execute store result entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:channeling",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count byte 1.0 run data get entity @e[type=item,tag=LOVcost,limit=1] Item.Count

kill @e[type=item,tag=LOVcost,limit=1]
