# tick

tag @e[type=villager,nbt={VillagerData:{profession:"minecraft:none"}}] remove LOViron

scoreboard players add tick less_op_villagers 1

execute if score tick less_op_villagers matches 5.. run function less_op_villagers:replace

scoreboard players enable @a less_op_villagers_help
execute as @a unless score @s less_op_villagers_help matches 0 at @s run function less_op_villagers:trigger
