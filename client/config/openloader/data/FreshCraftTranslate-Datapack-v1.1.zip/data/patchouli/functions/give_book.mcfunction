# Выдача книги игрокам, которые еще ее не получили
execute as @a[scores={hasBook=0}] run give @s patchouli:guide_book{patchouli:book="patchouli:freshbook"} 1
# Обновление scoreboard, чтобы отметить, что игрок получил книгу
execute as @a[scores={hasBook=0}] run scoreboard players set @s hasBook 1
