# max_level_book


# reduce level by 1 if enchantment is max level (and max level is greater than 1)
# whenever a new enchantment with a max level greater than 1 is added to the game, another command for it must be added below.

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:bane_of_arthropods",lvl:5s}]}}.tag.StoredEnchantments[{id:"minecraft:bane_of_arthropods",lvl:5s}].lvl set value 4s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:blast_protection",lvl:4s}]}}.tag.StoredEnchantments[{id:"minecraft:blast_protection",lvl:4s}].lvl set value 3s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:depth_strider",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:depth_strider",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:efficiency",lvl:5s}]}}.tag.StoredEnchantments[{id:"minecraft:efficiency",lvl:5s}].lvl set value 4s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:feather_falling",lvl:4s}]}}.tag.StoredEnchantments[{id:"minecraft:feather_falling",lvl:4s}].lvl set value 3s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:fire_aspect",lvl:2s}]}}.tag.StoredEnchantments[{id:"minecraft:fire_aspect",lvl:2s}].lvl set value 1s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:fire_protection",lvl:4s}]}}.tag.StoredEnchantments[{id:"minecraft:fire_protection",lvl:4s}].lvl set value 3s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:fortune",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:fortune",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:frost_walker",lvl:2s}]}}.tag.StoredEnchantments[{id:"minecraft:frost_walker",lvl:2s}].lvl set value 1s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:impaling",lvl:5s}]}}.tag.StoredEnchantments[{id:"minecraft:impaling",lvl:5s}].lvl set value 4s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:knockback",lvl:2s}]}}.tag.StoredEnchantments[{id:"minecraft:knockback",lvl:2s}].lvl set value 1s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:looting",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:looting",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:loyalty",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:loyalty",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:luck_of_the_sea",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:luck_of_the_sea",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:lure",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:lure",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:piercing",lvl:4s}]}}.tag.StoredEnchantments[{id:"minecraft:piercing",lvl:4s}].lvl set value 3s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:power",lvl:5s}]}}.tag.StoredEnchantments[{id:"minecraft:power",lvl:5s}].lvl set value 4s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:projectile_protection",lvl:4s}]}}.tag.StoredEnchantments[{id:"minecraft:projectile_protection",lvl:4s}].lvl set value 3s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:protection",lvl:4s}]}}.tag.StoredEnchantments[{id:"minecraft:protection",lvl:4s}].lvl set value 3s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:punch",lvl:2s}]}}.tag.StoredEnchantments[{id:"minecraft:punch",lvl:2s}].lvl set value 1s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:quick_charge",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:quick_charge",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:respiration",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:respiration",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:riptide",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:riptide",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:sharpness",lvl:5s}]}}.tag.StoredEnchantments[{id:"minecraft:sharpness",lvl:5s}].lvl set value 4s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:smite",lvl:5s}]}}.tag.StoredEnchantments[{id:"minecraft:smite",lvl:5s}].lvl set value 4s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:soul_speed",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:soul_speed",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:sweeping",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:sweeping",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:swift_sneak",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:swift_sneak",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:thorns",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:thorns",lvl:3s}].lvl set value 2s

data modify entity @s Offers{}.Recipes[].sell{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:unbreaking",lvl:3s}]}}.tag.StoredEnchantments[{id:"minecraft:unbreaking",lvl:3s}].lvl set value 2s


# increase cost if max level is 1 (then doubling if treasure enchantment)
# whenever a new enchantment with a max level of 1 is added to the game, another command and mcfunction for it must be added. make sure to set the scale to 2.0 if it's a treasure enchantment.

# -known bug: if a villager has two of the same enchanted book with a max level of 1 (rare but possible), the /data get will fail and the cost won't be increased. for example: if you have a villager with two separate trades for aqua affinity books and then add this datapack, neither of those trades will be increased in cost. if you have a villager with one aqua affinity book trade, it gets increased in cost, then you level up your villager and it gains another aqua affinity book trade, that second trade won't get increased in cost.
# i can't figure out a good way to fix this.

# non-treasure books
execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:aqua_affinity",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..19 run function less_op_villagers:replace/level_1_books/aqua_affinity

execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:channeling",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..19 run function less_op_villagers:replace/level_1_books/channeling

execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:flame",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..19 run function less_op_villagers:replace/level_1_books/flame

execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:infinity",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..19 run function less_op_villagers:replace/level_1_books/infinity

execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:multishot",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..19 run function less_op_villagers:replace/level_1_books/multishot

execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:silk_touch",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..19 run function less_op_villagers:replace/level_1_books/silk_touch

# treasure books
execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:binding_curse",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..38 run function less_op_villagers:replace/level_1_books/binding_curse

execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:vanishing_curse",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..38 run function less_op_villagers:replace/level_1_books/vanishing_curse

execute store result score emerald_cost less_op_villagers run data get entity @s Offers{}.Recipes[{sell:{id:"minecraft:enchanted_book",tag:{StoredEnchantments:[{id:"minecraft:mending",lvl:1s}]}}}].buy{id:"minecraft:emerald"}.Count
execute if score emerald_cost less_op_villagers matches 1..38 run function less_op_villagers:replace/level_1_books/mending

