# curing_discount/unchanged

scoreboard players set curing_discount less_op_villagers -1

function less_op_villagers:notify/curing_discount
