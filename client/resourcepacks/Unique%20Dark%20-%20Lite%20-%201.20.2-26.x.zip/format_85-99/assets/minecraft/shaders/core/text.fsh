#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif
    if (color.a < 0.1) {
        discard;
    }

    //Replacing Minecraft's title color
    if (color.r > 0.2509 && color.r < 0.2511
        && color.g > 0.2509 && color.g < 0.2511
        && color.b > 0.2509 && color.b < 0.2511) {
        color = vec4(1.0, 1.0, 1.0, 1.0);
    }

    // Replacing AE2's text color with #404040
    if (color.r > 0.24 && color.r < 0.26 &&
        color.g > 0.23 && color.g < 0.25 &&
        color.b > 0.32 && color.b < 0.33) {
        color = vec4(0.2509, 0.2509, 0.2509, 1.0);
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
