# AoA QuestLog Medieval Trial Report

## Scope

Created a non-destructive QuestLog trial overlay for Medieval Times only. This is a conveyance and UX trial, not a progression rewrite.

FTBQ source footprint before this trial: the handoff described 207 Medieval FTBQ nodes across five source chapter files. QuestLog trial footprint after this pass: 42 journal quests across five visible chapters.

## Backup status

- No existing `config/questlog/chapters/aoa_trial/medieval/` or `config/questlog/quests/aoa_trial/medieval/` folders existed, so no backup was needed.

## Files created

- `config/questlog/chapters/aoa_trial/medieval/00_threshold.json`
- `config/questlog/chapters/aoa_trial/medieval/01_first_mill.json`
- `config/questlog/chapters/aoa_trial/medieval/02_foundry_brass.json`
- `config/questlog/chapters/aoa_trial/medieval/03_relics_burrows.json`
- `config/questlog/chapters/aoa_trial/medieval/04_grove_hunt.json`
- `config/questlog/quests/aoa_trial/medieval/00_threshold/00_read_medieval_times.json`
- `config/questlog/quests/aoa_trial/medieval/00_threshold/01_stone_has_shape.json`
- `config/questlog/quests/aoa_trial/medieval/00_threshold/02_copper_teaches_metal.json`
- `config/questlog/quests/aoa_trial/medieval/00_threshold/03_hot_work_cold_edges.json`
- `config/questlog/quests/aoa_trial/medieval/00_threshold/04_blueprints_before_machines.json`
- `config/questlog/quests/aoa_trial/medieval/00_threshold/05_ready_for_machines.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/00_create_has_a_vocabulary.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/01_first_motion.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/02_transmit_stress.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/03_control_stress.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/04_read_the_machine.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/05_process_press_wash.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/06_move_items_on_purpose.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/07_move_fluids_on_purpose.json`
- `config/questlog/quests/aoa_trial/medieval/01_first_mill/09_plan_before_you_build.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/00_fire_clay_to_black_brick.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/01_build_the_black_foundry.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/02_casting_has_standards.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/03_heat_stability_throughput.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/04_coke_creosote_treated_wood.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/05_engineers_kit.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/06_low_voltage_vocabulary.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/07_brass_by_process.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/08_brass_automation_preview.json`
- `config/questlog/quests/aoa_trial/medieval/02_foundry_brass/09_carry_the_workshop.json`
- `config/questlog/quests/aoa_trial/medieval/03_relics_burrows/00_field_notes_after_foundry.json`
- `config/questlog/quests/aoa_trial/medieval/03_relics_burrows/01_garden_tools_living_soil.json`
- `config/questlog/quests/aoa_trial/medieval/03_relics_burrows/02_sample_not_herbarium.json`
- `config/questlog/quests/aoa_trial/medieval/03_relics_burrows/03_fungal_reagents.json`
- `config/questlog/quests/aoa_trial/medieval/03_relics_burrows/04_burrows_and_gnome_king.json`
- `config/questlog/quests/aoa_trial/medieval/03_relics_burrows/05_queen_fang_winter_teeth.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/00_the_hunt_opens.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/01_wroughtnaut_lesson.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/02_sculptor_and_naga.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/03_elokosa_tracks.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/04_dark_metal_omen.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/05_bonecaller_chain.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/06_hounds_and_broken_knights.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/07_monsterplus_curses_relics.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/08_ancient_hero.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/09_trialboard_one_hunt_many_roads.json`
- `config/questlog/quests/aoa_trial/medieval/04_grove_hunt/10_medieval_trial_close.json`
- `config/questlog/aoa_trial_medieval_report.md`

## Source FTBQ files inspected

- `config/ftbquests/quests/chapters/entering_the_iron_era.snbt`
- `config/ftbquests/quests/chapters/m1_first_mill.snbt`
- `config/ftbquests/quests/chapters/m2_metallurgy.snbt`
- `config/ftbquests/quests/chapters/m3_relics_and_burrows.snbt`
- `config/ftbquests/quests/chapters/m4_what_waits_in_the_grove.snbt`
- `config/ftbquests/quests/lang/en_us.snbt`

## Deliberate consolidations and reorder choices

- Threshold: condensed stone shaping, copper smithing, hot work, blueprint literacy, and a read-only machine-readiness marker from `entering_the_iron_era.snbt`.
- First Mill: condensed Create basics into vocabulary, motion, stress transmission, stress control, machine reading, processing, item routing, fluid routing, and optional schematic planning.
- First Mill reorder: moved brass casing, deployer, brass funnels and tunnels, mechanical crafters, sequenced gearshift, crushing wheels, flywheel, electron tube, rose quartz, mechanical arm, clockwork bearing, and rotation speed controller out of First Mill timing.
- Foundry/Brass: bridged Productive Metalworks fire clay and black foundry setup into casting, heat control, Immersive Engineering coke/treated wood, engineer tools, LV vocabulary, brass by process, and brass automation preview.
- Relics/Burrows: translated Alchemist's Garden as optional fieldcraft with a small tool/soil kit, representative plant sample, optional fungal reagents, Gnome King branch, and Spider Queen proof.
- Relics/Burrows reorder: moved Gnome King and Spider Queen-style garden boss material into the fieldcraft chapter instead of leaving them split from the garden context.
- Grove: kept combat focus through Wroughtnaut, Sculptor/Naga, Elokosa, Born in Chaos dark-metal chain, Bonecallers, hounds, Monster Plus casters/relics, Ancient Hero, a single OR trialboard approximation, and a no-reward close.
- Trialboard approximation: used one `questlog:or` objective with four `entity_kill` children because this pass does not implement the FTBQ any-3-of-4 gate logic.

## Omitted or deferred buckets

- No mod jars, KubeJS scripts, AStages files, FTBQ SNBT files, reward tables, or existing progression scripts were edited.
- No QuestLog command rewards, item rewards, loot-table rewards, FTBQ relay quests, AStages grants, or gamestage commands were created.
- First Mill omitted the shopping list and sand filter from the trial.
- Foundry/Brass deferred edelwood and edelwood oil to Renaissance or Forbidden Arcanus context.
- Foundry/Brass did not require IE side materials such as concrete, hempcrete, fertilizer, IE tank, or IE fluid pipe.
- ProductiveLib upgrades, rod casts, brass funnels, brass tunnels, sequenced gearshift, flywheel, rose quartz, electron tubes, mechanical arm, and clockwork bearing stayed optional/prose-only.
- Relics/Burrows omitted the full Mushroomite tool set, ring catalog, staff catalog, fireplace/decor side objects, every-plant herbarium behavior, and the giant catch-all quest.
- Yeti material stayed prose-only and was not required as a trial objective.
- Grove did not require Umvuthi, Sol Visage, Earthrend Gauntlet, geomancer armor, masks, spear, bluff rod, glowing jelly, Sir Pumpkinhead, corpse fly, Mr. Pumpkin, or minor mob/drop catalogs.
- No validation script was added; JSON parsing was performed directly.

## IDs not found or suspicious

- No prompt-listed objective ID was reported missing from the inspected Medieval source files.
- Born in Chaos IDs use the source-backed namespace `born_in_chaos_v1`, not `born_in_chaos`.
- Monster Plus IDs use the source-backed namespace `monsterplus`, not `monster_plus`.
- Wroughtnaut proof was simplified to `mowziesmobs:wrought_helmet` only because this pass reserves `questlog:or` for the Trialboard approximation; the Wrought Axe is mentioned in prose.

## QuestLog schema choices

- Chapter files use `name`, `icon`, `order`, `hidden`, `default_chapter`, and `translatable`.
- Quest files use `title`, `description`, `icon`, `chapter`, `sort_order`, `hidden`, `include_in_main`, `objectives`, and `requirements` only when a quest is gated.
- Objectives use `questlog:read`, `questlog:item_obtain`, `questlog:entity_kill`, `questlog:quest_complete`, and one documented `questlog:or` wrapper for Trialboard.
- Rewards are omitted entirely. No command, item, loot-table, stage, or FTBQ relay reward is present.
- `questlog:item_craft` was not used in this trial; item-obtain tracking is safer for modded component or NBT cases.

## Validation

- JSON parse result: passed for 48 JSON files using `python -m json.tool`.
- Minecraft was not launched. `/questlog reload` was not run. Runtime UI and objective behavior are not claimed proven.

## Manual runtime checklist

- Install or confirm the QuestLog jar in the clean test profile.
- Launch a clean profile/world for this pack.
- Run `/questlog reload`.
- Open QuestLog and verify five chapters: Threshold, First Mill, Foundry, Relics, Grove.
- Complete one read quest.
- Obtain one item objective and confirm it completes.
- Kill one entity objective and confirm it completes.
- Confirm no AStages progress changed.
- Confirm no FTBQ quest progress changed.
